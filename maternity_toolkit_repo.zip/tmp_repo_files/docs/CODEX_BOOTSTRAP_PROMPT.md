# CODEX Bootstrapping Prompt

Read `docs/PRD_SOURCE_OF_TRUTH.md` and `AGENTS.md`.  Implement only Phase 1 as defined in the PRD and summarised in `AGENTS.md`.  Create a React Native + Expo app in TypeScript with an onboarding screen, a due date calculator, local storage, and a settings screen.  Ensure the app is offline‑first and does not make network requests.  Follow the architecture guardrails and satisfy all non‑negotiable constraints.

Do not implement features listed as out of scope for Phase 1, such as payments, notifications, PDF export, symptom checkers, or cloud synchronisation.  Provide unit and integration tests, and verify that all linter and test scripts pass before completing each task.