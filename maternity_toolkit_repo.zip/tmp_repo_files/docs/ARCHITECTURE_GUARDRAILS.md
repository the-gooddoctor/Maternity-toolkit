# Architecture Guardrails

These guardrails establish the non‑negotiable architectural rules for the Seed maternity toolkit.  All future development must adhere to them.

## Offline‑first

* The app must run entirely offline; no network calls are permitted in Phase 1.
* Future phases may introduce optional cloud sync, but it must be explicitly feature‑flagged and disabled by default.

## Privacy and data protection

* Do not collect, transmit, or store any personal data beyond the due date or LMP input.  Do not track users.
* No analytics, push notifications, or third‑party SDKs.

## Modular architecture

* Organise code by feature, separating business logic from UI components.
* Use hooks for shared logic and helpers for pure functions.

## Type safety

* Use TypeScript throughout the codebase.
* Define and export interfaces/types for component props and context values.

## Consistent styling

* Use a central theme file for colours and spacing constants.
* Avoid inline styles; use `StyleSheet.create` where possible.