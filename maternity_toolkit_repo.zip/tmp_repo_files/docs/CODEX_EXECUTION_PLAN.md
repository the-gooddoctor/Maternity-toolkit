# CODEX Execution Plan

This plan describes the order in which the initial development tasks should be executed for Phase 1 of the Seed maternity toolkit.  Each step builds upon the previous one and ensures the app remains offline‑first and privacy‑respecting.

1. **Scaffold the app**
   * Use Expo CLI with TypeScript to initialise a new React Native project.
   * Configure Prettier and ESLint according to the project’s coding standards.
   * Add `@react‑native‑async‑storage/async‑storage` and testing dependencies.

2. **Create an onboarding screen**
   * Display the app’s purpose and disclaimer.
   * Collect either the estimated date of delivery (EDD) or the last menstrual period (LMP).
   * Validate dates and store them using local storage.

3. **Implement the due date calculator (F01)**
   * Use LMP or EDD to calculate gestational age and due date.
   * Show calculations in UK date format.
   * Provide helper text explaining the calculation assumptions (e.g. 40‑week gestation).

4. **Implement local storage**
   * Persist user input (EDD or LMP) and results using AsyncStorage.
   * Ensure data loads correctly on app startup and is cleared only through the settings screen.

5. **Create a settings screen**
   * Allow users to update their due date/LMP and clear stored data.
   * Present the disclaimer and privacy policy.

6. **Write tests**
   * Add unit tests for the date calculation logic.
   * Add integration tests for user flows in onboarding and settings.

7. **Verify offline behaviour**
   * Audit code to ensure no network calls exist.
   * Test the app in airplane mode to confirm full functionality.

8. **Final quality checks**
   * Run `npm run lint` and fix any issues.
   * Ensure all tests pass.
   * Build the app in release mode to verify there are no unexpected errors.