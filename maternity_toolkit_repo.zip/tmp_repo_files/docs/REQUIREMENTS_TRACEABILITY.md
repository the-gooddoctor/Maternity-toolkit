# Requirements Traceability Matrix

This matrix maps the PRD’s requirement identifiers to their corresponding implementation status.  Update the status as tasks are completed.

| Requirement ID | Description                                 | Implementation reference | Status      |
| -------------- | ------------------------------------------- | ------------------------ | ----------- |
| F01            | Due date calculator                         | `src/screens/DueDate`    | Not started |
| F02            | Weight tracker (future phase, out of scope) | N/A                      | Out of scope|
| SED-SAF-001    | Offline‑first, privacy‑respecting design    | `AGENTS.md` & codebase   | In progress |
| SED-CC-001     | Clear disclaimer message                    | `src/components/Disclaimer` | Not started |
| ...            | ...                                         | ...                      | ...         |

Add additional rows as you parse more requirements from the PRD.  Use this table to ensure each requirement is addressed in the codebase.