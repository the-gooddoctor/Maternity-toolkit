# CODEX Task Queue

This file outlines a series of small, well‑defined tasks for Codex to execute sequentially.  Each task includes a brief description and a definition of done (DoD).

## Tasks

### 1. Scaffold project
* **Description:** Initialise a new Expo app with TypeScript.  Configure Prettier and ESLint.
* **DoD:** `package.json` exists with necessary dependencies; the app launches successfully via `npx expo start`.

### 2. Onboarding screen
* **Description:** Create a screen that welcomes the user, explains the app’s purpose and limitations, and collects either the EDD or LMP.  Validate the input and store it locally.
* **DoD:** Users can input and save a date through the UI.  Data persists across app restarts.

### 3. Due date calculator (F01)
* **Description:** Implement functions to calculate gestational age and due date based on LMP or EDD.  Display results in a user‑friendly format.
* **DoD:** The calculations are correct for typical gestation durations; unit tests cover edge cases.

### 4. Settings screen
* **Description:** Provide a settings screen where users can update their due date or LMP, clear stored data, and view the disclaimer.
* **DoD:** All settings options work as described and persist changes appropriately.

### 5. Tests
* **Description:** Write unit tests for calculation logic and integration tests for user flows.  Use Jest and React Native Testing Library.
* **DoD:** Test suite runs without failures; code coverage meets project standards.

### 6. Final checks
* **Description:** Run linter, ensure there are no network calls, and build the app in release mode.
* **DoD:** No lint errors remain; tests pass; the app works offline in release mode.