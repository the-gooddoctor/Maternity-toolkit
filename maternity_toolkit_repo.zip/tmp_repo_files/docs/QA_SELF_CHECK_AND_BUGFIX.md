# QA Self‑Check and Bug‑Fix Guide

To ensure high‑quality code and a stable user experience, follow this self‑check and bug‑fix loop for each task:

1. **Run automated tests**
   * Execute `npm run test` after implementing each task.
   * Fix any test failures immediately.  Update or extend tests only when necessary and documented.

2. **Run linter and formatter**
   * Execute `npm run lint` and fix all linting issues.
   * Ensure Prettier formatting is applied consistently.

3. **Manual testing**
   * Test the app on both iOS and Android emulators or devices.
   * Verify that the feature works offline and persists data across restarts.

4. **Review requirements**
   * Cross‑check the implemented functionality against the PRD and the task definition of done.
   * If the implementation deviates, adjust the code or update the requirements with approval.

5. **Bug fixing**
   * When issues are discovered, write a failing test if one does not already exist.
   * Fix the bug, ensuring the new test passes, and run the full test suite.

6. **Peer review**
   * If working in a team, submit a pull request for peer review.  Address feedback promptly.