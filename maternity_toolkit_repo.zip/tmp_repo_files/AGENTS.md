# Seed Maternity Toolkit – AGENTS.md

## Project overview

Seed is a privacy‑first, offline UK maternity toolkit that empowers expectant parents with a gestational age and due date calculator and other educational tools.  It is not a clinical device; it offers information only and must clearly state that it does not provide medical advice.

## Scope and Phase 1

This repository will be built in phases.  The first phase includes:

* **App shell:** A basic React Native app scaffold using TypeScript and Expo.
* **Onboarding:** A screen explaining the app’s purpose and collecting the estimated date of delivery (EDD) or last menstrual period (LMP) from the user.
* **Due date calculator (F01):** Calculate gestational age and due date from the LMP or user‑entered EDD, displaying results in UK date format.
* **Local storage:** Persist user data locally on the device using `@react‑native‑async‑storage/async‑storage` or a similar offline storage mechanism.
* **Settings:** A screen for users to view and update their due date, clear local data, and view the disclaimer.

## Non‑negotiable constraints

* **Offline‑first:** The app must function entirely without an internet connection.  No network calls are allowed in Phase 1.
* **Privacy:** Do not collect or transmit any personal data.  No user accounts, analytics, or third‑party trackers.
* **UK wording and units:** All dates should follow UK day‑month‑year formatting and use British English.
* **Clinical safety:** Include a clear disclaimer stating that the app provides general information only and is not a substitute for professional medical advice.

## Tech stack guidelines

* Use **React Native** with **Expo** and **TypeScript** for a predictable build environment.
* Implement modular, testable code.  Organise source files under `src/` and group code by feature (e.g. components, screens, hooks).
* Use **Jest** and **@testing‑library/react‑native** for unit and integration tests.
* Provide scripts in `package.json` for linting (`npm run lint`), testing (`npm run test`), and starting the app (`npx expo start`).

## Folder structure

```
.
├── AGENTS.md                         # This file (agent instructions)
├── docs/
│   ├── PRD_SOURCE_OF_TRUTH.md       # Full product requirements document
│   ├── CODEX_BOOTSTRAP_PROMPT.md    # First prompt for Codex
│   ├── CODEX_EXECUTION_PLAN.md      # High‑level execution plan
│   ├── CODEX_TASK_QUEUE.md          # Ordered task queue for Codex
│   ├── ARCHITECTURE_GUARDRAILS.md   # Non‑negotiable architecture rules
│   ├── QA_SELF_CHECK_AND_BUGFIX.md  # Self‑check and bug‑fix guide
│   └── REQUIREMENTS_TRACEABILITY.md # Traceability matrix
├── src/
│   ├── components/
│   ├── screens/
│   ├── hooks/
│   ├── utils/
│   └── …
└── …
```

## Commands

* **Install dependencies:** `npm install`
* **Start the app:** `npx expo start`
* **Run tests:** `npm run test`
* **Run linter:** `npm run lint`

## Definition of done

Phase 1 is complete when:

* The app runs on both iOS and Android with an onboarding flow, due date calculator, local storage, and settings screen.
* There are no network calls and no external dependencies beyond those specified in the package file.
* All test and lint commands pass without errors.