import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { mmkvStorage } from './mmkvStorage';

export interface KickSession {
  id: string;
  date: string;
  movements: number[];
  startTimestamp: number;
  endTimestamp: number | null;
  totalDurationMs: number | null;
}

interface KicksState {
  sessions: KickSession[];
  addSession: (session: KickSession) => void;
  addMovement: (sessionId: string, timestamp: number) => void;
  endSession: (sessionId: string, endTimestamp: number) => void;
  deleteSession: (sessionId: string) => void;
  resetAll: () => void;
}

export const useKicksStore = create<KicksState>()(
  persist(
    (set) => ({
      sessions: [],
      addSession: (session) => set((s) => ({ sessions: [session, ...s.sessions] })),
      addMovement: (sessionId, timestamp) => set((s) => ({
        sessions: s.sessions.map((x) => x.id === sessionId ? { ...x, movements: [...x.movements, timestamp] } : x),
      })),
      endSession: (sessionId, endTimestamp) => set((s) => ({
        sessions: s.sessions.map((x) => x.id === sessionId ? {
          ...x,
          endTimestamp,
          totalDurationMs: endTimestamp - x.startTimestamp,
        } : x),
      })),
      deleteSession: (sessionId) => set((s) => ({ sessions: s.sessions.filter((x) => x.id !== sessionId) })),
      resetAll: () => set({ sessions: [] }),
    }),
    { name: 'seed-kicks', storage: createJSONStorage(() => mmkvStorage) }
  )
);
