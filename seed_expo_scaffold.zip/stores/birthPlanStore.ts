import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { mmkvStorage } from './mmkvStorage';

export interface BirthPlanSection {
  id: string;
  title: string;
  selections: string[];
  notes: string;
}

interface BirthPlanState {
  sections: BirthPlanSection[];
  completed: boolean;
  setSections: (sections: BirthPlanSection[]) => void;
  updateSection: (id: string, selections: string[], notes: string) => void;
  setCompleted: (completed: boolean) => void;
  resetAll: () => void;
}

export const useBirthPlanStore = create<BirthPlanState>()(
  persist(
    (set) => ({
      sections: [],
      completed: false,
      setSections: (sections) => set({ sections }),
      updateSection: (id, selections, notes) => set((s) => ({
        sections: s.sections.map((x) => x.id === id ? { ...x, selections, notes } : x),
      })),
      setCompleted: (completed) => set({ completed }),
      resetAll: () => set({ sections: [], completed: false }),
    }),
    { name: 'seed-birth-plan', storage: createJSONStorage(() => mmkvStorage) }
  )
);
