import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { mmkvStorage } from './mmkvStorage';

export interface ChecklistItem {
  id: string;
  label: string;
  checked: boolean;
  category?: string;
  isCustom?: boolean;
}

interface ChecklistState {
  hospitalBag: ChecklistItem[];
  todos: ChecklistItem[];
  setList: (listKey: 'hospitalBag' | 'todos', items: ChecklistItem[]) => void;
  toggleItem: (listKey: 'hospitalBag' | 'todos', id: string) => void;
  addItem: (listKey: 'hospitalBag' | 'todos', item: ChecklistItem) => void;
  deleteItem: (listKey: 'hospitalBag' | 'todos', id: string) => void;
  resetAll: () => void;
}

export const useChecklistStore = create<ChecklistState>()(
  persist(
    (set) => ({
      hospitalBag: [],
      todos: [],
      setList: (listKey, items) => set({ [listKey]: items } as Partial<ChecklistState>),
      toggleItem: (listKey, id) => set((s) => ({
        [listKey]: s[listKey].map((x) => x.id === id ? { ...x, checked: !x.checked } : x),
      } as Partial<ChecklistState>)),
      addItem: (listKey, item) => set((s) => ({ [listKey]: [...s[listKey], item] } as Partial<ChecklistState>)),
      deleteItem: (listKey, id) => set((s) => ({ [listKey]: s[listKey].filter((x) => x.id !== id) } as Partial<ChecklistState>)),
      resetAll: () => set({ hospitalBag: [], todos: [] }),
    }),
    { name: 'seed-checklists', storage: createJSONStorage(() => mmkvStorage) }
  )
);
