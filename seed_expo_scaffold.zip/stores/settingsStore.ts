import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { mmkvStorage } from './mmkvStorage';

export type UserMode = 'pregnant' | 'partner';
export type PregnancyType = 'singleton' | 'twins' | 'triplets_plus';
export type BirthSetting = 'hospital' | 'birth_centre' | 'home' | 'caesarean' | 'undecided';
export type WeightUnit = 'kg' | 'stones';
export type TrackingStatus = 'active' | 'paused' | 'ended';

interface SettingsState {
  edd: string | null;
  lmp: string | null;
  userMode: UserMode;
  pregnancyType: PregnancyType;
  birthSetting: BirthSetting;
  weightUnit: WeightUnit;
  maternityUnitPhone: string | null;
  trackingStatus: TrackingStatus;
  disclaimerAccepted: boolean;
  proUnlocked: boolean;
  ageConfirmed: boolean;
  userName: string | null;
  setEdd: (edd: string) => void;
  setLmp: (lmp: string) => void;
  setUserMode: (mode: UserMode) => void;
  setPregnancyType: (type: PregnancyType) => void;
  setBirthSetting: (setting: BirthSetting) => void;
  setWeightUnit: (unit: WeightUnit) => void;
  setMaternityUnitPhone: (phone: string | null) => void;
  setTrackingStatus: (status: TrackingStatus) => void;
  acceptDisclaimer: () => void;
  unlockPro: () => void;
  confirmAge: () => void;
  resetAll: () => void;
}

const initialState = {
  edd: null,
  lmp: null,
  userMode: 'pregnant' as UserMode,
  pregnancyType: 'singleton' as PregnancyType,
  birthSetting: 'undecided' as BirthSetting,
  weightUnit: 'kg' as WeightUnit,
  maternityUnitPhone: null,
  trackingStatus: 'active' as TrackingStatus,
  disclaimerAccepted: false,
  proUnlocked: false,
  ageConfirmed: false,
  userName: null,
};

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      ...initialState,
      setEdd: (edd) => set({ edd }),
      setLmp: (lmp) => set({ lmp }),
      setUserMode: (userMode) => set({ userMode }),
      setPregnancyType: (pregnancyType) => set({ pregnancyType }),
      setBirthSetting: (birthSetting) => set({ birthSetting }),
      setWeightUnit: (weightUnit) => set({ weightUnit }),
      setMaternityUnitPhone: (maternityUnitPhone) => set({ maternityUnitPhone }),
      setTrackingStatus: (trackingStatus) => set({ trackingStatus }),
      acceptDisclaimer: () => set({ disclaimerAccepted: true }),
      unlockPro: () => set({ proUnlocked: true }),
      confirmAge: () => set({ ageConfirmed: true }),
      resetAll: () => set({ ...initialState }),
    }),
    {
      name: 'seed-settings',
      storage: createJSONStorage(() => mmkvStorage),
      version: 1,
    }
  )
);
