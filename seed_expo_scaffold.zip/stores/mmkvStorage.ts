import { MMKV } from 'react-native-mmkv';
import type { StateStorage } from 'zustand/middleware';

export const mmkv = new MMKV({ id: 'seed-storage', encryptionKey: 'seed-enc-key' });

export const mmkvStorage: StateStorage = {
  getItem: (name) => mmkv.getString(name) ?? null,
  setItem: (name, value) => { mmkv.set(name, value); },
  removeItem: (name) => { mmkv.delete(name); },
};
