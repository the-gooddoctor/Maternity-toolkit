import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { mmkvStorage } from './mmkvStorage';

export interface Appointment {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  notes: string;
  whatToExpect: string;
  isNHSPrePopulated: boolean;
  reminderScheduled: boolean;
}

interface AppointmentsState {
  appointments: Appointment[];
  addAppointment: (appt: Appointment) => void;
  updateAppointment: (id: string, updates: Partial<Appointment>) => void;
  deleteAppointment: (id: string) => void;
  resetAll: () => void;
}

export const useAppointmentsStore = create<AppointmentsState>()(
  persist(
    (set) => ({
      appointments: [],
      addAppointment: (appt) => set((s) => ({ appointments: [...s.appointments, appt] })),
      updateAppointment: (id, updates) => set((s) => ({ appointments: s.appointments.map((x) => x.id === id ? { ...x, ...updates } : x) })),
      deleteAppointment: (id) => set((s) => ({ appointments: s.appointments.filter((x) => x.id !== id) })),
      resetAll: () => set({ appointments: [] }),
    }),
    { name: 'seed-appointments', storage: createJSONStorage(() => mmkvStorage) }
  )
);
