import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { mmkvStorage } from './mmkvStorage';

export interface FavouriteName {
  name: string;
  gender: 'boy' | 'girl' | 'unisex';
  origin: string;
  meaning: string;
}

interface NamesState {
  myFavourites: FavouriteName[];
  partnerFavourites: FavouriteName[];
  addFavourite: (list: 'my' | 'partner', name: FavouriteName) => void;
  removeFavourite: (list: 'my' | 'partner', name: string) => void;
  resetAll: () => void;
}

export const useNamesStore = create<NamesState>()(
  persist(
    (set) => ({
      myFavourites: [],
      partnerFavourites: [],
      addFavourite: (list, item) => set((s) => {
        const key = list === 'my' ? 'myFavourites' : 'partnerFavourites';
        if (s[key].some((x) => x.name === item.name)) return {};
        return { [key]: [...s[key], item] } as Partial<NamesState>;
      }),
      removeFavourite: (list, name) => set((s) => {
        const key = list === 'my' ? 'myFavourites' : 'partnerFavourites';
        return { [key]: s[key].filter((x) => x.name !== name) } as Partial<NamesState>;
      }),
      resetAll: () => set({ myFavourites: [], partnerFavourites: [] }),
    }),
    { name: 'seed-names', storage: createJSONStorage(() => mmkvStorage) }
  )
);
