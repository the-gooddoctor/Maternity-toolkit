import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { mmkvStorage } from './mmkvStorage';

export interface WeightEntry {
  id: string;
  date: string;
  weightKg: number;
  note?: string;
}

interface WeightState {
  entries: WeightEntry[];
  addEntry: (entry: WeightEntry) => void;
  updateEntry: (id: string, updates: Partial<WeightEntry>) => void;
  deleteEntry: (id: string) => void;
  resetAll: () => void;
}

export const useWeightStore = create<WeightState>()(
  persist(
    (set) => ({
      entries: [],
      addEntry: (entry) => set((s) => ({ entries: [entry, ...s.entries].sort((a, b) => a.date.localeCompare(b.date)) })),
      updateEntry: (id, updates) => set((s) => ({ entries: s.entries.map((x) => x.id === id ? { ...x, ...updates } : x) })),
      deleteEntry: (id) => set((s) => ({ entries: s.entries.filter((x) => x.id !== id) })),
      resetAll: () => set({ entries: [] }),
    }),
    { name: 'seed-weight', storage: createJSONStorage(() => mmkvStorage) }
  )
);
