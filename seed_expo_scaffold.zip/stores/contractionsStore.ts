import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { mmkvStorage } from './mmkvStorage';

export interface Contraction {
  id: string;
  startTimestamp: number;
  endTimestamp: number;
  durationMs: number;
  intervalFromPreviousMs: number | null;
}

export interface ContractionSession {
  id: string;
  startedAt: string;
  contractions: Contraction[];
  isActive: boolean;
}

interface ContractionsState {
  sessions: ContractionSession[];
  addSession: (session: ContractionSession) => void;
  addContraction: (sessionId: string, contraction: Contraction) => void;
  endSession: (sessionId: string) => void;
  deleteSession: (sessionId: string) => void;
  resetAll: () => void;
}

export const useContractionsStore = create<ContractionsState>()(
  persist(
    (set) => ({
      sessions: [],
      addSession: (session) => set((s) => ({ sessions: [session, ...s.sessions] })),
      addContraction: (sessionId, contraction) => set((s) => ({
        sessions: s.sessions.map((x) => x.id === sessionId ? { ...x, contractions: [...x.contractions, contraction] } : x),
      })),
      endSession: (sessionId) => set((s) => ({
        sessions: s.sessions.map((x) => x.id === sessionId ? { ...x, isActive: false } : x),
      })),
      deleteSession: (sessionId) => set((s) => ({ sessions: s.sessions.filter((x) => x.id !== sessionId) })),
      resetAll: () => set({ sessions: [] }),
    }),
    { name: 'seed-contractions', storage: createJSONStorage(() => mmkvStorage) }
  )
);
