import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ScreenContainer } from './ScreenContainer';
import { colours } from '../../constants/colours';

export const PlaceholderScreen = ({ title, subtitle }: { title: string; subtitle?: string }) => (
  <ScreenContainer>
    <View style={styles.card}>
      <Text style={styles.title}>{title}</Text>
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
  </ScreenContainer>
);

const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 8 },
  title: { fontSize: 22, fontWeight: '700', color: colours.textPrimary },
  subtitle: { fontSize: 15, color: colours.textSecondary, lineHeight: 20 },
});
