import React from 'react';
import { StyleSheet, Text } from 'react-native';

const fmt = (ms: number) => {
  const totalSeconds = Math.floor(ms / 1000);
  const mins = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
  const secs = (totalSeconds % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
};

export const TimerDisplay = ({ ms }: { ms: number }) => <Text style={styles.text}>{fmt(ms)}</Text>;

const styles = StyleSheet.create({ text: { fontSize: 56, fontWeight: '800', textAlign: 'center' } });
