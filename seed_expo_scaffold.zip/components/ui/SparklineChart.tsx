import React from 'react';
import { View, Text } from 'react-native';

export const SparklineChart = () => <View><Text>Trend chart placeholder</Text></View>;
