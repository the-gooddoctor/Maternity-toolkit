import React from 'react';
import { Pressable, StyleSheet, Text } from 'react-native';
import { colours } from '../../constants/colours';

export const BigButton = ({ label, onPress }: { label: string; onPress: () => void }) => (
  <Pressable style={styles.button} onPress={onPress}>
    <Text style={styles.text}>{label}</Text>
  </Pressable>
);

const styles = StyleSheet.create({
  button: { minHeight: 80, borderRadius: 14, backgroundColor: colours.primary, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16 },
  text: { color: 'white', fontSize: 20, fontWeight: '700' },
});
