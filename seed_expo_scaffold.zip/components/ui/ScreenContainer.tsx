import React from 'react';
import { SafeAreaView, ScrollView, StyleSheet, ViewProps } from 'react-native';
import { colours } from '../../constants/colours';

export const ScreenContainer = ({ children }: React.PropsWithChildren<ViewProps>) => (
  <SafeAreaView style={styles.safe}>
    <ScrollView contentContainerStyle={styles.content}>{children}</ScrollView>
  </SafeAreaView>
);

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colours.background },
  content: { padding: 16, gap: 12 },
});
