import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colours } from '../../constants/colours';

export const WeekCard = ({ week, title, body }: { week: number; title: string; body: string }) => (
  <View style={styles.card}>
    <Text style={styles.kicker}>Week {week}</Text>
    <Text style={styles.title}>{title}</Text>
    <Text style={styles.body}>{body}</Text>
  </View>
);

const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 6 },
  kicker: { color: colours.primaryDark, fontWeight: '700' },
  title: { color: colours.textPrimary, fontSize: 18, fontWeight: '700' },
  body: { color: colours.textSecondary, lineHeight: 20 },
});
