import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colours } from '../../constants/colours';

export const ClinicalBanner = ({ text }: { text: string }) => (
  <View style={styles.wrap} accessibilityRole="summary">
    <Text style={styles.text}>{text}</Text>
  </View>
);

const styles = StyleSheet.create({
  wrap: { backgroundColor: '#FEF3C7', borderWidth: 1, borderColor: '#F59E0B', borderRadius: 12, padding: 12 },
  text: { color: '#78350F', fontSize: 14, lineHeight: 18, fontWeight: '500' },
});
