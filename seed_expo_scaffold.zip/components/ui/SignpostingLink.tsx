import React from 'react';
import { Linking, Pressable, StyleSheet, Text } from 'react-native';
import { colours } from '../../constants/colours';

export const SignpostingLink = ({ label, url }: { label: string; url: string }) => (
  <Pressable onPress={() => Linking.openURL(url)} style={styles.link}>
    <Text style={styles.text}>{label}</Text>
  </Pressable>
);

const styles = StyleSheet.create({
  link: { paddingVertical: 8 },
  text: { color: colours.info, fontWeight: '600' },
});
