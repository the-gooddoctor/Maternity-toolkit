import React from 'react';
import { StyleSheet, View } from 'react-native';
import { colours } from '../../constants/colours';

export const ProgressBar = ({ progress }: { progress: number }) => (
  <View style={styles.track}>
    <View style={[styles.fill, { width: `${Math.max(0, Math.min(100, progress))}%` }]} />
  </View>
);

const styles = StyleSheet.create({
  track: { height: 10, borderRadius: 999, backgroundColor: colours.surfaceSubtle, overflow: 'hidden' },
  fill: { height: '100%', backgroundColor: colours.primary },
});
