import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useProGate } from '../../hooks/useProGate';
import { colours } from '../../constants/colours';

export const ProGate = ({ children }: React.PropsWithChildren) => {
  const { isPro } = useProGate();
  if (isPro) return <>{children}</>;
  return (
    <View style={styles.card}>
      <Text style={styles.title}>Pro feature</Text>
      <Text style={styles.body}>Unlock Seed Pro for a one-time purchase to use this feature.</Text>
      <Pressable style={styles.button} onPress={() => router.push('/pro-unlock')}>
        <Text style={styles.buttonText}>Open Pro unlock</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 10 },
  title: { fontSize: 18, fontWeight: '700', color: colours.textPrimary },
  body: { color: colours.textSecondary },
  button: { backgroundColor: colours.primary, padding: 12, borderRadius: 10 },
  buttonText: { color: 'white', fontWeight: '600', textAlign: 'center' },
});
