import React from 'react';
import { Text, View } from 'react-native';

export default function PlaceholderComponent() {
  return <View><Text>Weight chart placeholder</Text></View>;
}
