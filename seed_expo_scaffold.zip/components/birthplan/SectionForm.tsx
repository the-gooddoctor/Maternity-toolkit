import React from 'react';
import { Text, View } from 'react-native';

export default function PlaceholderComponent() {
  return <View><Text>Birth plan section form placeholder</Text></View>;
}
