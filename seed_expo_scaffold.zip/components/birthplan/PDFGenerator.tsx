import React from 'react';
import { Text, View } from 'react-native';

export default function PlaceholderComponent() {
  return <View><Text>PDF generator placeholder</Text></View>;
}
