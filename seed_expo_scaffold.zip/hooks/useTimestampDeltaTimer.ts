import { useCallback, useEffect, useRef, useState } from 'react';
import { AppState } from 'react-native';
import { mmkv } from '../stores/mmkvStorage';

export const useTimestampDeltaTimer = (storageKey: string) => {
  const key = `${storageKey}_start`;
  const [startTimestamp, setStartTimestamp] = useState<string | undefined>(() => mmkv.getString(key) ?? undefined);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const recalculate = useCallback(() => {
    const ts = startTimestamp ?? mmkv.getString(key) ?? undefined;
    if (ts) {
      setElapsedMs(Date.now() - parseInt(ts, 10));
      setIsRunning(true);
    }
  }, [key, startTimestamp]);

  useEffect(() => {
    const ts = mmkv.getString(key) ?? undefined;
    if (ts) {
      setStartTimestamp(ts);
      recalculate();
    }
  }, [key, recalculate]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') recalculate();
    });
    return () => sub.remove();
  }, [recalculate]);

  useEffect(() => {
    if (!isRunning) return;
    intervalRef.current = setInterval(() => recalculate(), 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, recalculate]);

  const start = useCallback(() => {
    const now = Date.now().toString();
    mmkv.set(key, now);
    setStartTimestamp(now);
    setElapsedMs(0);
    setIsRunning(true);
  }, [key]);

  const stop = useCallback(() => {
    const ts = startTimestamp ?? mmkv.getString(key) ?? undefined;
    const duration = ts ? Date.now() - parseInt(ts, 10) : 0;
    mmkv.delete(key);
    setStartTimestamp(undefined);
    setIsRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
    return duration;
  }, [key, startTimestamp]);

  const reset = useCallback(() => {
    mmkv.delete(key);
    setStartTimestamp(undefined);
    setElapsedMs(0);
    setIsRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
  }, [key]);

  return { elapsedMs, isRunning, start, stop, reset };
};
