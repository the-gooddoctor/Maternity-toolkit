import { useSettingsStore } from '../stores/settingsStore';

export const useTrackingStatus = () => {
  const trackingStatus = useSettingsStore((s) => s.trackingStatus);
  return {
    trackingStatus,
    isActive: trackingStatus === 'active',
    isPaused: trackingStatus === 'paused',
    isEnded: trackingStatus === 'ended',
  };
};
