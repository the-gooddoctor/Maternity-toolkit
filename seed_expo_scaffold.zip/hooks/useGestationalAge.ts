import { useMemo } from 'react';
import { useSettingsStore } from '../stores/settingsStore';
import { daysUntilDate, getGestationalAgeFromEdd, getTermWindowProgress } from '../utils/dateCalculations';

export const useGestationalAge = () => {
  const edd = useSettingsStore((s) => s.edd);
  return useMemo(() => {
    if (!edd) return null;
    const ga = getGestationalAgeFromEdd(edd);
    return {
      ...ga,
      daysUntilEdd: daysUntilDate(edd),
      termWindowProgress: getTermWindowProgress(edd),
    };
  }, [edd]);
};
