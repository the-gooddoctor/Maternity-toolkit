import weeks from '../data/weeks.json';
import { useGestationalAge } from './useGestationalAge';

export const useCurrentWeekData = () => {
  const ga = useGestationalAge();
  if (!ga) return null;
  const week = ga.weeks;
  const item = (weeks as Array<any>).find((x) => x.week === week) ?? null;
  return item;
};
