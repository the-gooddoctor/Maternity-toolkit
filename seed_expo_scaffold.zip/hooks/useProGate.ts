import { useSettingsStore } from '../stores/settingsStore';

export const useProGate = () => {
  const proUnlocked = useSettingsStore((s) => s.proUnlocked);
  return { isPro: proUnlocked };
};
