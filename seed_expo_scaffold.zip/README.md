# Seed Maternity Toolkit (Expo scaffold)

This is a PRD-aligned Expo + expo-router starter scaffold for the Seed maternity toolkit.

## Purpose

- Gives Codex a concrete, buildable file structure that matches the PRD section 6.6
- Keeps architecture constraints visible in code
- Leaves feature logic intentionally lightweight so Codex can implement requirement IDs cleanly

## First run

```bash
npm install
npx expo start
```

## Important

- PRD is the source of truth
- This scaffold is a starting point, not the finished app
- All user data must remain on-device only (MMKV)
- No analytics, telemetry, crash reporting, or remote config
