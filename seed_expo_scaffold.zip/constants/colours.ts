export const colours = {
  background: '#FDF8F4',
  surface: '#FFFFFF',
  surfaceSubtle: '#F5F0EB',
  textPrimary: '#2D2A26',
  textSecondary: '#6B6560',
  textTertiary: '#9B9590',
  primary: '#7B9E87',
  primaryDark: '#5C7A66',
  primaryLight: '#E8F0EB',
  secondary: '#C4A882',
  warning: '#D97706',
  danger: '#B91C1C',
  info: '#1D4ED8',
  labourModeBg: '#1A1A2E',
  labourModeSurface: '#22223B',
  labourModeText: '#F8FAFC',
};

export type AppColours = typeof colours;
