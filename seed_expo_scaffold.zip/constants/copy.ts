export const copy = {
  appName: 'Seed',
  noInterpretationBanner: 'Seed records your information but does not interpret it. If you are worried, contact your midwife or maternity unit.',
};
