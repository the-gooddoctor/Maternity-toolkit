export const layout = {
  screenPadding: 16,
  cardRadius: 14,
  tapTargetMin: 44,
  bigButtonMin: 80,
};
