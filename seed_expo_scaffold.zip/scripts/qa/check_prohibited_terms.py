from pathlib import Path

PROHIBITED = [
    'diagnose',
    'diagnosis',
    'you should go to hospital now',
    'labour stage',
]

paths = [Path('app'), Path('components'), Path('constants'), Path('data')]
violations = []
for p in paths:
    if not p.exists():
        continue
    for f in p.rglob('*'):
        if f.suffix.lower() not in {'.ts', '.tsx', '.json', '.md'}:
            continue
        text = f.read_text(encoding='utf-8', errors='ignore').lower()
        for term in PROHIBITED:
            if term in text:
                violations.append((str(f), term))

if violations:
    for file, term in violations:
        print(f'Violation: {term!r} in {file}')
    raise SystemExit(1)

print('No prohibited terms found in scanned files.')
