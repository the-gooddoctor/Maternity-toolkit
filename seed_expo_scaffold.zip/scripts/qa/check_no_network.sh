#!/usr/bin/env bash
set -euo pipefail
if grep -R "fetch\|axios\|XMLHttpRequest" app components hooks stores utils --include='*.ts' --include='*.tsx' ; then
  echo "Potential network call found. Review against SED-ARCH-001."
  exit 1
fi

echo "No obvious network calls found in source folders."
