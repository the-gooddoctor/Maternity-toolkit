# Codex Agent Guardrails for Seed

## Source of truth
- `Seed_Maternity_Toolkit_PRD_v2_0.md` is the source of truth.
- Requirement IDs must be preserved and traced in commits and PR notes.

## Non-negotiables
- Offline-first, on-device only storage.
- No network requests except RevenueCat purchase validation and explicit external links.
- No analytics or tracking SDKs.
- No medical interpretation or advice from user-entered data.
- Keep UK language and NHS-aligned wording.

## Build approach
- Implement in vertical slices by feature (F01 to F10).
- For each feature: code, test, self-check, bug-fix, update traceability.
- Prefer small commits with clear conventional commit messages.
