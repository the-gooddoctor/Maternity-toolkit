export const birthPlanHtml = (title: string, body: string) => `
<html>
  <head><meta charset="utf-8" /><style>body { font-family: Arial; padding: 24px; }</style></head>
  <body>
    <h1>${title}</h1>
    <div>${body}</div>
  </body>
</html>`;
