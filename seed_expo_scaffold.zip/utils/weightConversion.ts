export const kgToStonesLbs = (kg: number) => {
  const totalLbs = kg * 2.2046226218;
  const stones = Math.floor(totalLbs / 14);
  const lbs = Number((totalLbs % 14).toFixed(1));
  return { stones, lbs };
};

export const stonesLbsToKg = (stones: number, lbs: number) => Number((((stones * 14) + lbs) / 2.2046226218).toFixed(2));
