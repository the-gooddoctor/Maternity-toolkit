export type ContractionLite = { durationMs: number; intervalFromPreviousMs: number | null };

export const averageMs = (values: number[]) => values.length ? Math.round(values.reduce((a, b) => a + b, 0) / values.length) : 0;

export const getRollingAverages = (items: ContractionLite[], take = 3) => {
  const recent = items.slice(-take);
  return {
    averageDurationMs: averageMs(recent.map((x) => x.durationMs)),
    averageIntervalMs: averageMs(recent.map((x) => x.intervalFromPreviousMs).filter((x): x is number => x !== null)),
  };
};
