import * as Notifications from 'expo-notifications';

export const requestNotificationPermission = async () => {
  const result = await Notifications.requestPermissionsAsync();
  return result.status === 'granted';
};

export const scheduleLocalReminder = async (title: string, body: string, trigger: Notifications.NotificationTriggerInput) => {
  return Notifications.scheduleNotificationAsync({ content: { title, body }, trigger });
};
