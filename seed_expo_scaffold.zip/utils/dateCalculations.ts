export type GestationalAge = { weeks: number; days: number; totalDays: number };

export const calculateEddFromLmp = (lmpIso: string): Date => {
  const edd = new Date(lmpIso);
  edd.setDate(edd.getDate() + 280);
  return edd;
};

export const getGestationalAgeFromEdd = (eddIso: string, nowDate: Date = new Date()): GestationalAge => {
  const edd = new Date(eddIso);
  const conceptionEstimate = new Date(edd);
  conceptionEstimate.setDate(conceptionEstimate.getDate() - 280);
  const diffMs = nowDate.getTime() - conceptionEstimate.getTime();
  const totalDays = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
  const weeks = Math.floor(totalDays / 7);
  const days = totalDays % 7;
  return { weeks, days, totalDays };
};

export const daysUntilDate = (iso: string, nowDate: Date = new Date()): number => {
  const target = new Date(iso);
  const diffMs = target.getTime() - nowDate.getTime();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
};

export const getTermWindowProgress = (eddIso: string, nowDate: Date = new Date()) => {
  const ga = getGestationalAgeFromEdd(eddIso, nowDate).totalDays;
  const start = 37 * 7;
  const end = 42 * 7;
  const pct = ((ga - start) / (end - start)) * 100;
  return Math.max(0, Math.min(100, pct));
};
