import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function Screen() { return <PlaceholderScreen title="Mental wellbeing support" subtitle="Section 4.4 signposting placeholder." />; }
