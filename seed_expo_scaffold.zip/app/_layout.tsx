import '../global.css';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSettingsStore } from '../stores/settingsStore';

export default function RootLayout() {
  const accepted = useSettingsStore((s) => s.disclaimerAccepted);
  const ageConfirmed = useSettingsStore((s) => s.ageConfirmed);

  return (
    <>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false }}>
        {!accepted || !ageConfirmed ? (
          <Stack.Screen name="onboarding/welcome" />
        ) : null}
      </Stack>
    </>
  );
}
