import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function NotFound() { return <PlaceholderScreen title="Not found" subtitle="This screen does not exist yet." />; }
