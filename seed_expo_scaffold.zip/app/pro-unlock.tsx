import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function Screen() { return <PlaceholderScreen title="Unlock Seed Pro" subtitle="RevenueCat paywall placeholder. No subscriptions, one-time purchase." />; }
