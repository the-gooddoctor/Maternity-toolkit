import React from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenContainer } from '../components/ui/ScreenContainer';
import { useSettingsStore } from '../stores/settingsStore';
import { colours } from '../constants/colours';

export default function SettingsScreen() {
  const edd = useSettingsStore((s) => s.edd);
  const setEdd = useSettingsStore((s) => s.setEdd);
  const proUnlocked = useSettingsStore((s) => s.proUnlocked);
  const unlockPro = useSettingsStore((s) => s.unlockPro);

  return (
    <ScreenContainer>
      <View style={styles.card}>
        <Text style={styles.title}>Settings</Text>
        <Text style={styles.label}>Estimated due date (ISO)</Text>
        <TextInput value={edd ?? ''} onChangeText={setEdd} placeholder="2026-06-01" style={styles.input} />
        <Text style={styles.note}>Codex should replace this with proper date pickers and onboarding-linked settings.</Text>
      </View>
      <View style={styles.card}>
        <Text style={styles.label}>Pro access</Text>
        <Text style={styles.note}>{proUnlocked ? 'Pro is unlocked (local test flag).' : 'Pro is locked.'}</Text>
        {!proUnlocked ? (
          <Pressable style={styles.button} onPress={unlockPro}><Text style={styles.buttonText}>Local test unlock</Text></Pressable>
        ) : null}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 8 },
  title: { fontSize: 22, fontWeight: '700', color: colours.textPrimary },
  label: { fontWeight: '600', color: colours.textPrimary },
  input: { borderWidth: 1, borderColor: '#D6D3D1', borderRadius: 10, padding: 10, backgroundColor: '#fff' },
  note: { color: colours.textSecondary, lineHeight: 20 },
  button: { backgroundColor: colours.primary, borderRadius: 10, padding: 12 },
  buttonText: { color: '#fff', textAlign: 'center', fontWeight: '700' },
});
