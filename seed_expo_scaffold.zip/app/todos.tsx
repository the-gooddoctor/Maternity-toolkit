import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function Screen() { return <PlaceholderScreen title="Pregnancy to-do checklist" subtitle="F08 placeholder." />; }
