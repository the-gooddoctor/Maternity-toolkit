import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function Screen() { return <PlaceholderScreen title="Kick history" subtitle="F04 pattern view placeholder." />; }
