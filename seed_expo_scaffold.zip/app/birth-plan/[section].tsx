import { useLocalSearchParams } from 'expo-router';
import { PlaceholderScreen } from '../../components/ui/PlaceholderScreen';

export default function BirthPlanSectionScreen() {
  const { section } = useLocalSearchParams<{ section: string }>();
  return <PlaceholderScreen title="Birth plan section" subtitle={`Section: ${section ?? 'unknown'}`} />;
}
