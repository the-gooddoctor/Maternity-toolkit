import { PlaceholderScreen } from '../../components/ui/PlaceholderScreen';
export default function BirthPlanIndex() { return <PlaceholderScreen title="Birth plan" subtitle="F07 hub placeholder with section list and PDF export." />; }
