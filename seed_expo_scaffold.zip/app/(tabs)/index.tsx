import { Text, View, StyleSheet } from 'react-native';
import { Link } from 'expo-router';
import { ScreenContainer } from '../../components/ui/ScreenContainer';
import { WeekCard } from '../../components/ui/WeekCard';
import { ClinicalBanner } from '../../components/ui/ClinicalBanner';
import { copy } from '../../constants/copy';
import { useCurrentWeekData } from '../../hooks/useCurrentWeekData';
import { useGestationalAge } from '../../hooks/useGestationalAge';
import { colours } from '../../constants/colours';

export default function HomeTab() {
  const ga = useGestationalAge();
  const week = useCurrentWeekData();

  return (
    <ScreenContainer>
      <ClinicalBanner text={copy.noInterpretationBanner} />
      <View style={styles.card}>
        <Text style={styles.h1}>Seed</Text>
        {ga ? (
          <>
            <Text style={styles.body}>{ga.weeks} weeks and {ga.days} days</Text>
            <Text style={styles.body}>{ga.daysUntilEdd} days to due date</Text>
          </>
        ) : (
          <Text style={styles.body}>Set your due date in onboarding or settings.</Text>
        )}
        <Link href="/settings" style={styles.link}>Open settings</Link>
      </View>
      {week ? <WeekCard week={week.week} title={week.title} body={week.summary} /> : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 6 },
  h1: { fontSize: 24, fontWeight: '700', color: colours.textPrimary },
  body: { color: colours.textSecondary },
  link: { color: colours.info, fontWeight: '600', marginTop: 6 },
});
