import { Link } from 'expo-router';
import { StyleSheet, Text, View } from 'react-native';
import { ScreenContainer } from '../../components/ui/ScreenContainer';
import { colours } from '../../constants/colours';

const links = [
  ['/contraction-timer', 'Contraction timer'],
  ['/kick-counter', 'Kick counter'],
  ['/weight-tracker', 'Weight tracker'],
  ['/birth-plan', 'Birth plan'],
  ['/appointments', 'Appointments'],
  ['/names', 'Baby names'],
] as const;

export default function ToolsTab() {
  return (
    <ScreenContainer>
      <View style={styles.card}>
        <Text style={styles.title}>Tools</Text>
        {links.map(([href, label]) => (
          <Link key={href} href={href as any} style={styles.link}>{label}</Link>
        ))}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 10 },
  title: { fontSize: 20, fontWeight: '700', color: colours.textPrimary },
  link: { color: colours.info, fontWeight: '600' },
});
