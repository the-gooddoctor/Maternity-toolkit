import { Link } from 'expo-router';
import { ScreenContainer } from '../../components/ui/ScreenContainer';
import { View, Text, StyleSheet } from 'react-native';
import { colours } from '../../constants/colours';

export default function MoreTab() {
  return (
    <ScreenContainer>
      <View style={styles.card}>
        <Text style={styles.title}>More</Text>
        <Link href="/settings" style={styles.link}>Settings</Link>
        <Link href="/privacy" style={styles.link}>Privacy</Link>
        <Link href="/disclaimer" style={styles.link}>Disclaimer</Link>
        <Link href="/wellbeing" style={styles.link}>Wellbeing support</Link>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 10 },
  title: { fontSize: 20, fontWeight: '700', color: colours.textPrimary },
  link: { color: colours.info, fontWeight: '600' },
});
