import { Link } from 'expo-router';
import { PlaceholderScreen } from '../../components/ui/PlaceholderScreen';

export default function ChecklistsTab() {
  return <PlaceholderScreen title="Checklists" subtitle="Open hospital bag or pregnancy to-do lists from this hub." />;
}
