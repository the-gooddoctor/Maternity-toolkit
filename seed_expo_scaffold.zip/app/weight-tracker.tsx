import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function Screen() { return <PlaceholderScreen title="Weight tracker" subtitle="F05 placeholder with chart and NICE reference band copy." />; }
