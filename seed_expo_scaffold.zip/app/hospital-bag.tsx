import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function Screen() { return <PlaceholderScreen title="Hospital bag checklist" subtitle="F06 placeholder." />; }
