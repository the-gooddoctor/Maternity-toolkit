import { PlaceholderScreen } from '../../components/ui/PlaceholderScreen';
export default function NameFavourites() { return <PlaceholderScreen title="Name favourites" subtitle="My shortlist and partner shortlist placeholder." />; }
