import { PlaceholderScreen } from '../../components/ui/PlaceholderScreen';
export default function NamesIndex() { return <PlaceholderScreen title="Baby names" subtitle="F10 name search placeholder." />; }
