import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useKeepAwake } from 'expo-keep-awake';
import * as Haptics from 'expo-haptics';
import { ScreenContainer } from '../components/ui/ScreenContainer';
import { useTimestampDeltaTimer } from '../hooks/useTimestampDeltaTimer';
import { TimerDisplay } from '../components/ui/TimerDisplay';
import { colours } from '../constants/colours';

export default function LabourModeScreen() {
  useKeepAwake();
  const timer = useTimestampDeltaTimer('labour_mode');

  return (
    <ScreenContainer>
      <View style={styles.card}>
        <Text style={styles.title}>Labour Mode</Text>
        <TimerDisplay ms={timer.elapsedMs} />
        <Pressable
          style={styles.big}
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            timer.isRunning ? timer.stop() : timer.start();
          }}
        >
          <Text style={styles.bigText}>{timer.isRunning ? 'Stop' : 'Start'}</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colours.labourModeBg, borderRadius: 14, padding: 16, gap: 12 },
  title: { color: colours.labourModeText, fontSize: 22, fontWeight: '700', textAlign: 'center' },
  big: { minHeight: 120, borderRadius: 16, backgroundColor: colours.primary, alignItems: 'center', justifyContent: 'center' },
  bigText: { color: '#fff', fontWeight: '800', fontSize: 28 },
});
