import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function Screen() { return <PlaceholderScreen title="Disclaimer" subtitle="Mandatory legal and safety disclaimer text placeholder." />; }
