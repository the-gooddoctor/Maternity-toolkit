import { useLocalSearchParams } from 'expo-router';
import { PlaceholderScreen } from '../../components/ui/PlaceholderScreen';

export default function AppointmentDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  return <PlaceholderScreen title="Appointment" subtitle={`Appointment id: ${id ?? 'new'}`} />;
}
