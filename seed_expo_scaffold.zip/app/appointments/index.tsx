import { PlaceholderScreen } from '../../components/ui/PlaceholderScreen';
export default function AppointmentsIndex() { return <PlaceholderScreen title="Appointments" subtitle="F09 appointment list placeholder." />; }
