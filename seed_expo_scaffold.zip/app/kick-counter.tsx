import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function Screen() { return <PlaceholderScreen title="Kick counter" subtitle="F04 placeholder. Session logging and pattern view." />; }
