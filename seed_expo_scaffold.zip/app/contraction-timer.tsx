import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Link } from 'expo-router';
import { ScreenContainer } from '../components/ui/ScreenContainer';
import { ClinicalBanner } from '../components/ui/ClinicalBanner';
import { TimerDisplay } from '../components/ui/TimerDisplay';
import { ProGate } from '../components/ui/ProGate';
import { copy } from '../constants/copy';
import { colours } from '../constants/colours';
import { useTimestampDeltaTimer } from '../hooks/useTimestampDeltaTimer';
import { createId } from '../utils/idGenerator';
import { useContractionsStore } from '../stores/contractionsStore';

export default function ContractionTimerScreen() {
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const timer = useTimestampDeltaTimer('contraction');
  const sessions = useContractionsStore((s) => s.sessions);
  const addSession = useContractionsStore((s) => s.addSession);
  const addContraction = useContractionsStore((s) => s.addContraction);
  const endSession = useContractionsStore((s) => s.endSession);

  const activeSession = useMemo(() => sessions.find((s) => s.id === activeSessionId) ?? null, [sessions, activeSessionId]);

  const handleStartContraction = () => {
    if (!activeSessionId) {
      const sessionId = createId('contraction_session');
      addSession({ id: sessionId, startedAt: new Date().toISOString(), contractions: [], isActive: true });
      setActiveSessionId(sessionId);
    }
    timer.start();
  };

  const handleStopContraction = () => {
    const durationMs = timer.stop();
    if (!activeSessionId) return;
    const prev = activeSession?.contractions.at(-1);
    const now = Date.now();
    addContraction(activeSessionId, {
      id: createId('cx'),
      startTimestamp: now - durationMs,
      endTimestamp: now,
      durationMs,
      intervalFromPreviousMs: prev ? (now - prev.endTimestamp) : null,
    });
  };

  const handleEndSession = () => {
    if (activeSessionId) endSession(activeSessionId);
    setActiveSessionId(null);
    timer.reset();
  };

  return (
    <ScreenContainer>
      <ProGate>
        <ClinicalBanner text={copy.noInterpretationBanner} />
        <View style={styles.card}>
          <Text style={styles.title}>Contraction timer</Text>
          <TimerDisplay ms={timer.elapsedMs} />
          {!timer.isRunning ? (
            <Pressable style={styles.button} onPress={handleStartContraction}><Text style={styles.buttonText}>Start contraction</Text></Pressable>
          ) : (
            <Pressable style={styles.buttonSecondary} onPress={handleStopContraction}><Text style={styles.buttonText}>End contraction</Text></Pressable>
          )}
          <Pressable style={styles.buttonGhost} onPress={handleEndSession}><Text style={styles.ghostText}>End session</Text></Pressable>
          <Link href="/labour-mode" style={styles.link}>Open Labour Mode</Link>
        </View>
      </ProGate>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 12 },
  title: { fontSize: 22, fontWeight: '700', color: colours.textPrimary, textAlign: 'center' },
  button: { minHeight: 80, borderRadius: 14, backgroundColor: colours.primary, justifyContent: 'center' },
  buttonSecondary: { minHeight: 80, borderRadius: 14, backgroundColor: colours.secondary, justifyContent: 'center' },
  buttonGhost: { minHeight: 44, borderRadius: 10, borderWidth: 1, borderColor: '#D6D3D1', justifyContent: 'center' },
  buttonText: { color: '#fff', textAlign: 'center', fontWeight: '700', fontSize: 18 },
  ghostText: { color: colours.textPrimary, textAlign: 'center', fontWeight: '600' },
  link: { color: colours.info, textAlign: 'center', fontWeight: '600' },
});
