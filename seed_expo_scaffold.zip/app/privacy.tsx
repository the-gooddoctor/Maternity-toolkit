import { PlaceholderScreen } from '../components/ui/PlaceholderScreen';
export default function Screen() { return <PlaceholderScreen title="Privacy" subtitle="Offline-only, no data collection policy placeholder." />; }
