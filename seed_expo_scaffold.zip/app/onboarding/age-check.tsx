import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '../../components/ui/ScreenContainer';
import { useSettingsStore } from '../../stores/settingsStore';
import { colours } from '../../constants/colours';

export default function AgeCheck() {
  const confirmAge = useSettingsStore((s) => s.confirmAge);
  const router = useRouter();
  return (
    <ScreenContainer>
      <View style={styles.card}>
        <Text style={styles.title}>Age confirmation</Text>
        <Text style={styles.body}>This app is intended for users aged 16 or over.</Text>
        <Pressable style={styles.button} onPress={() => { confirmAge(); router.replace('/(tabs)'); }}>
          <Text style={styles.buttonText}>I am 16 or over</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 10 },
  title: { fontSize: 22, fontWeight: '700', color: colours.textPrimary },
  body: { color: colours.textSecondary, lineHeight: 20 },
  button: { backgroundColor: colours.primary, borderRadius: 10, padding: 12 },
  buttonText: { color: '#fff', textAlign: 'center', fontWeight: '700' },
});
