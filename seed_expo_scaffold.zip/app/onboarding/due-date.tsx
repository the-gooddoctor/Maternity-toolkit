import { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '../../components/ui/ScreenContainer';
import { useSettingsStore } from '../../stores/settingsStore';
import { colours } from '../../constants/colours';

export default function DueDateOnboarding() {
  const [value, setValue] = useState('');
  const setEdd = useSettingsStore((s) => s.setEdd);
  const router = useRouter();
  return (
    <ScreenContainer>
      <View style={styles.card}>
        <Text style={styles.title}>When is your baby due?</Text>
        <TextInput style={styles.input} value={value} onChangeText={setValue} placeholder="YYYY-MM-DD" />
        <Pressable style={styles.button} onPress={() => { if (value) setEdd(value); router.push('/onboarding/age-check'); }}>
          <Text style={styles.buttonText}>Continue</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 10 },
  title: { fontSize: 22, fontWeight: '700', color: colours.textPrimary },
  input: { borderWidth: 1, borderColor: '#D6D3D1', borderRadius: 10, padding: 10, backgroundColor: '#fff' },
  button: { backgroundColor: colours.primary, borderRadius: 10, padding: 12 },
  buttonText: { color: '#fff', textAlign: 'center', fontWeight: '700' },
});
