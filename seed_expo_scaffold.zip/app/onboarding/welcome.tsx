import { Link } from 'expo-router';
import { PlaceholderScreen } from '../../components/ui/PlaceholderScreen';

export default function WelcomeScreen() {
  return <PlaceholderScreen title="Welcome to Seed" subtitle="Onboarding flow placeholder. Next: disclaimer, due date, age check." />;
}
