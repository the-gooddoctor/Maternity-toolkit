import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '../../components/ui/ScreenContainer';
import { useSettingsStore } from '../../stores/settingsStore';
import { colours } from '../../constants/colours';

export default function DisclaimerAccept() {
  const acceptDisclaimer = useSettingsStore((s) => s.acceptDisclaimer);
  const router = useRouter();
  return (
    <ScreenContainer>
      <View style={styles.card}>
        <Text style={styles.title}>Important</Text>
        <Text style={styles.body}>Seed is a tracker and information tool. It does not give medical advice or interpret your data.</Text>
        <Pressable style={styles.button} onPress={() => { acceptDisclaimer(); router.push('/onboarding/due-date'); }}>
          <Text style={styles.buttonText}>I understand</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
const styles = StyleSheet.create({
  card: { backgroundColor: colours.surface, borderRadius: 14, padding: 16, gap: 10 },
  title: { fontSize: 22, fontWeight: '700', color: colours.textPrimary },
  body: { color: colours.textSecondary, lineHeight: 20 },
  button: { backgroundColor: colours.primary, borderRadius: 10, padding: 12 },
  buttonText: { color: '#fff', textAlign: 'center', fontWeight: '700' },
});
