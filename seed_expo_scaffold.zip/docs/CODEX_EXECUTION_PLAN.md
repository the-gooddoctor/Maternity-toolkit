# Execution Plan

1. Verify scaffold compiles
2. Implement foundation (routing, theme, stores, hooks)
3. Build F01 and F02 first
4. Add Pro gate and RevenueCat wrapper
5. Build Pro features F03-F05
6. Build F06-F10
7. Cross-cutting modes and pathways
8. QA, text audit, and release prep
