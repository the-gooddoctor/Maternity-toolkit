# Codex Cloud Build Prompt (paste into Codex)

Use the prompt in the root response message from ChatGPT. This file is a local copy for convenience.
