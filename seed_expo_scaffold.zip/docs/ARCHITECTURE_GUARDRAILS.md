# Architecture Guardrails

- SED-ARCH-001: Zero network dependency after install and purchase validation
- SED-ARCH-002: On-device only MMKV storage
- SED-ARCH-003: No tracking SDKs
- SED-ARCH-004: Zustand + MMKV persistence
- SED-ARCH-005: Static content bundled as JSON
- SED-ARCH-006: Single Expo codebase
